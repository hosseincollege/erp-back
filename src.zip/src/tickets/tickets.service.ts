// Backend | src/tickets/tickets.service.ts

import { Injectable, InternalServerErrorException, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateTicketDto } from './dto/create-ticket.dto';

@Injectable()
export class TicketsService {
  private readonly logger = new Logger(TicketsService.name);

  constructor(private prisma: PrismaService) {}

  async create(createTicketDto: CreateTicketDto) {
    try {
      // ۱. پیدا کردن یک کاربر پیش‌فرض (فیلد creatorId در شِما اجباری است)
      // توجه: در آینده این ID باید از Request/Auth گرفته شود
      let defaultUser = await this.prisma.user.findFirst();
      
      // اگر کاربر وجود نداشت، برای جلوگیری از کرش، یک کاربر سیستمی موقت بساز
      if (!defaultUser) {
        this.logger.warn('No user found in database. Creating a system user...');
        defaultUser = await this.prisma.user.create({
          data: {
            name: 'System Admin',
            email: 'admin@erp-pro.local',
            password: 'system_generated_password', // در محیط واقعی هش شود
            role: 'ADMIN',
          },
        });
      }

      // ۲. تولید شماره تیکت (بهبود یافته برای جلوگیری از تداخل)
      const lastTicket = await this.prisma.ticket.findFirst({
        orderBy: { createdAt: 'desc' },
        select: { ticketNumber: true }
      });

      let nextNumber = 1;
      if (lastTicket && lastTicket.ticketNumber.startsWith('TCK-')) {
        const lastNum = parseInt(lastTicket.ticketNumber.split('-')[1]);
        if (!isNaN(lastNum)) nextNumber = lastNum + 1;
      }
      const ticketNumber = `TCK-${String(nextNumber).padStart(5, '0')}`;

      // ۳. آماده‌سازی داده‌ها برای درج در دیتابیس
      const ticketData: any = {
        ticketNumber,
        title: createTicketDto.title,
        description: createTicketDto.description,
        customerName: createTicketDto.customerName || null,
        customerPhone: createTicketDto.customerPhone || null,
        priority: createTicketDto.priority || 'MEDIUM',
        status: createTicketDto.status || 'OPEN',
        source: createTicketDto.source || 'PHONE',
        creatorId: defaultUser.id,
      };

      // مدیریت اختیاری بودن مشتری (Foreign Key Safety)
      if (createTicketDto.customerId && createTicketDto.customerId.trim() !== '') {
        ticketData.customerId = createTicketDto.customerId;
      }

      const ticket = await this.prisma.ticket.create({
        data: ticketData,
        include: {
          customer: true,
          creator: true,
        },
      });

      return {
        success: true,
        data: ticket,
      };
    } catch (error) {
      // لاگ دقیق برای عیب‌یابی در ترمینال بک‌اِند
      this.logger.error(`[CREATE TICKET ERROR]: ${error.message}`, error.stack);
      
      throw new InternalServerErrorException({
        message: 'خطا در ثبت تیکت در پایگاه داده',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }

  async findAll() {
    try {
      return await this.prisma.ticket.findMany({
        include: {
          customer: true,
          creator: true,
        },
        orderBy: {
          createdAt: 'desc',
        },
      });
    } catch (error) {
      this.logger.error(`[FIND ALL TICKETS ERROR]: ${error.message}`);
      throw new InternalServerErrorException('خطا در دریافت لیست تیکت‌ها');
    }
  }

  async findOne(id: string) {
    try {
      const ticket = await this.prisma.ticket.findFirst({
        where: {
          OR: [
            { id: id },
            { ticketNumber: id },
          ],
        },
        include: {
          customer: true,
          creator: true,
          messages: {
            include: {
              author: true
            },
            orderBy: {
              createdAt: 'asc'
            }
          }
        },
      });

      if (!ticket) {
        throw new NotFoundException('تیکت یافت نشد');
      }

      return { success: true, data: ticket };
    } catch (error) {
      this.logger.error(`[FIND ONE TICKET ERROR]: ${error.message}`);
      throw new InternalServerErrorException('خطا در دریافت جزئیات تیکت');
    }
  }
}
